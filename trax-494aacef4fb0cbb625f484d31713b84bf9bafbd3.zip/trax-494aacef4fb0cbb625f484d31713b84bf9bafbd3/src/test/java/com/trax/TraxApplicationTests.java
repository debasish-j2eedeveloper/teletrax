package com.trax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraxApplicationTests {

	@Test
	void contextLoads() {
	}

}
