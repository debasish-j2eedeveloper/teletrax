package com.trax.utils;

public interface EmailService {
	public void sendSimpleMessage(String to, String sub, String text);
}
